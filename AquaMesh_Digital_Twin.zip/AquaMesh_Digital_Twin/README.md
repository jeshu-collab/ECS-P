# AquaMesh_Digital_Twin
Run guide only — the full explanation (logic, folders, calibration, hardware, API) is in `../README.md`.

    pip install -r requirements.txt
    python3 aquamesh_pi.py            # hardware      python3 aquamesh_pi.py --sim storm   # demo
    python3 tests/test_engine.py      # tests         open http://localhost:8000 → press 8
