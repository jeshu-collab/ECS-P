@echo off
cd /d "%~dp0"
echo AquaMesh evidence-driven flood twin
echo   Hardware : python aquamesh_pi.py              (reads all detected COM ports)
echo   Demo     : python aquamesh_pi.py --sim storm  (simulated nodes, all values tagged SIMULATED)
echo   Tests    : python tests\test_engine.py
echo   Open     : http://localhost:8000
python aquamesh_pi.py %*
pause
