#!/usr/bin/env python3
"""
AquaMesh Raspberry Pi gateway.  This file only does I/O; all reasoning lives in the engine/ package.

  ESP32 FLOOD01 ─┐  LoRa 433 MHz
  ESP32 GAS01  ──┴──> TTGO receiver ──USB serial──> this script ──> engine.Twin (validate, reason, record)
                                                       │
                          buzzer GPIO 17  <────────────┤  LOCAL: works with no browser and no Internet
                          http://<pi-ip>:8000 <────────┘  dashboard (public/) + JSON API

Run:      python3 aquamesh_pi.py                 (real hardware)
Demo:     python3 aquamesh_pi.py --sim storm     (simulated nodes; every value tagged SIMULATED)
"""
import argparse, csv, json, os, shutil, sys, threading, time
from datetime import datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = list_ports = None

from engine import calibration as C
from engine.packet import parse_line
from engine.pipeline import Twin
from engine.simulator import SimRunner, VClock, SCENARIOS

# ───────────────────────── CONFIG ─────────────────────────
BAUD = 115200
BUZZER_GPIO = 17            # active-LOW 3-pin buzzer (unchanged from your original script)
BUZZER_SECONDS = 1.5
CRITICAL_REPEAT_S = 10      # while the engine says CRITICAL (or gas hazard) the buzzer repeats
SERIAL_CANDIDATES = ["/dev/ttyUSB0", "/dev/ttyACM0", "/dev/ttyUSB1", "/dev/ttyACM1", "/dev/serial0", "/dev/ttyAMA0", "/dev/ttyS0"]
# ──────────────────────────────────────────────────────────

ROOT = os.path.dirname(os.path.abspath(__file__))
PUBLIC = os.path.join(ROOT, "public")          # ONLY this folder is served; source, config and logs are never exposed
LOG_DIR = os.path.join(ROOT, "logs")
CFG = os.path.join(ROOT, "config", "calibration.json")


class Buzzer:
    """Non-blocking, local-only buzzer."""
    def __init__(self, pin):
        self.available, self.dev, self.on_until, self._t = False, None, 0.0, None
        try:
            from gpiozero import OutputDevice
            self.dev = OutputDevice(pin, active_high=False, initial_value=False)
            self.available = True
        except Exception as e:
            print(f"[buzzer] GPIO unavailable ({e}); running without buzzer")

    def pulse(self, seconds=BUZZER_SECONDS):
        self.on_until = max(self.on_until, time.time() + seconds)
        if self._t and self._t.is_alive():
            return
        self._t = threading.Thread(target=self._run, daemon=True)
        self._t.start()

    def _run(self):
        if self.dev: self.dev.on()
        while time.time() < self.on_until:
            time.sleep(0.05)
        if self.dev: self.dev.off()

    @property
    def is_on(self): return time.time() < self.on_until

    def close(self):
        if self.dev: self.dev.off()


class Gateway:
    def __init__(self, twin, buzzer, sim=None):
        self.twin, self.buzzer, self.sim = twin, buzzer, sim
        self.ports, self.lock, self.last_crit_pulse = set(), threading.Lock(), 0.0
        os.makedirs(LOG_DIR, exist_ok=True)
        path = os.path.join(LOG_DIR, "readings.csv")
        new = not os.path.exists(path)
        self._f = open(path, "a", newline="", buffering=1)
        self._w = csv.writer(self._f)
        if new:
            self._w.writerow(["time_iso", "from", "pkt", "status", "rain_raw", "hx_raw", "mq_raw", "soil_raw", "rssi", "snr"])
        twin.on_event = self.on_event

    def feed(self, line):
        d, text = parse_line(line)
        if d is None:
            return
        pkt = self.twin.ingest(d, text, line)
        if pkt is None:
            return
        v = pkt["values"]
        if not self.twin.sim:                          # CSV stays as an export format (real packets only)
            self._w.writerow([datetime.now().isoformat(timespec="seconds"), pkt["hw"], pkt["pkt"], pkt["status"], v.get("RAIN"), v.get("HX"),
                              v.get("MQ"), v.get("SOIL"), pkt.get("rssi"), pkt.get("snr")])
        if pkt["status"] == "ALERT" and pkt["hw"] in ("FLOOD01", "GAS01"):
            self.buzzer.pulse()                       # same behaviour as your original script

    def on_event(self, e):
        if e["severity"] == "critical":
            self.buzzer.pulse(3.0)

    def watchdog(self):
        """1 Hz: re-run the reasoning (so silence is noticed even with no packets) and drive the local alarm."""
        while True:
            time.sleep(1)
            self.twin.uart_ok = bool(self.ports) or self.twin.sim
            try:
                a = self.twin.assess()["a"]
            except Exception as ex:                   # never let reasoning kill the alarm loop
                print(f"[engine] assess error: {ex}")
                continue
            if (a["flood"] == "CRITICAL" or a["gas"] == "WARNING") and time.time() - self.last_crit_pulse > CRITICAL_REPEAT_S:
                self.last_crit_pulse = time.time()
                self.buzzer.pulse(2.0)

    def gateway_extra(self):
        return {"serial_port": ", ".join(sorted(self.ports)) or ("SIMULATOR" if self.twin.sim else None), "baud": BAUD,
                "cpu_temp_c": _cpu_temp(), "disk_used_pct": _disk_pct(), "buzzer_available": self.buzzer.available,
                "buzzer_on": self.buzzer.is_on, "system_uptime_s": _sys_uptime(), "serial_connected": bool(self.ports) or self.twin.sim}


def _cpu_temp():
    try: return round(int(open("/sys/class/thermal/thermal_zone0/temp").read()) / 1000, 1)
    except Exception: return None
def _sys_uptime():
    try: return int(float(open("/proc/uptime").read().split()[0]))
    except Exception: return None
def _disk_pct():
    try:
        u = shutil.disk_usage("/"); return round(100 * u.used / u.total)
    except Exception: return None


# ───────────────────────── serial ─────────────────────────
def serial_ports(forced):
    if forced:
        return [p.strip() for p in forced.split(",") if p.strip()]
    found = [p.device for p in list_ports.comports()]
    if sys.platform.startswith("win"):
        return found
    return list(dict.fromkeys(found + [p for p in SERIAL_CANDIDATES if os.path.exists(p)]))


def serial_worker(gw, port):
    while True:
        try:
            s = serial.Serial()
            s.port, s.baudrate, s.timeout = port, BAUD, 0.5
            s.dtr = s.rts = False                 # opening the port must not reset the ESP32
            s.open()
            ser = s
        except Exception:
            time.sleep(3)
            continue
        with gw.lock:
            gw.ports.add(port)
        gw.twin._event("UART_CONNECTED", "info", "Sensor UART connected", f"{port} @ {BAUD}", None, gw.twin.clock())
        try:
            while True:
                b = ser.readline()
                if not b:
                    continue
                msg = b.decode(errors="replace").strip()
                if msg:
                    print(msg.encode("ascii", errors="replace").decode("ascii"))
                    gw.feed(msg)
        except Exception as e:
            gw.twin._event("UART_LOST", "warn", "Sensor UART lost", f"{port}: {e}", None, gw.twin.clock())
        finally:
            with gw.lock:
                gw.ports.discard(port)
            try: ser.close()
            except Exception: pass
        time.sleep(2)


def serial_loop(gw, forced):
    started = set()
    while True:
        for p in serial_ports(forced):
            if p not in started:
                started.add(p)
                threading.Thread(target=serial_worker, args=(gw, p), daemon=True).start()
        time.sleep(5)


# ───────────────────────── HTTP ─────────────────────────
def make_handler(gw):
    twin = gw.twin

    class H(SimpleHTTPRequestHandler):
        def __init__(self, *a, **k): super().__init__(*a, directory=PUBLIC, **k)
        def log_message(self, *a): pass
        def end_headers(self):
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            super().end_headers()

        def _json(self, obj, code=200):
            body = json.dumps(obj, default=str).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            u = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            p = u.path.rstrip("/")
            if p.startswith("/api/"):
                try:
                    if p == "/api/twin/state":
                        return self._json(twin.snapshot(gw.gateway_extra()))
                    if p == "/api/twin/assessment":
                        return self._json(twin.assessment_public(twin.last or twin.assess()))
                    if p == "/api/twin/why":
                        return self._json(twin.why(q.get("goal", "flood_watch")))
                    if p == "/api/twin/events":
                        return self._json(twin.db.events(int(q.get("limit", 50))))
                    if p == "/api/twin/event":
                        r = twin.db.event_row(int(q.get("id", 0)))
                        if not r:
                            return self._json({"error": "not found"}, 404)
                        r["evidence"] = json.loads(r.pop("evidence_json"))
                        return self._json(r)
                    if p == "/api/twin/timeline":
                        since = twin.clock() - 60 * float(q.get("minutes", 15))
                        return self._json({"points": twin.db.timeline(since), "transitions": twin.db.transitions(30)})
                    if p == "/api/twin/replay":
                        r = twin.replay(int(q.get("id", 0)))
                        return self._json(r or {"error": "not found"}, 200 if r else 404)
                    if p == "/api/sim/scenarios":
                        return self._json({"sim": bool(gw.sim), "scenarios": SCENARIOS, "current": gw.sim.world.scenario if gw.sim else None,
                                           "blockage": gw.sim.world.blockage if gw.sim else None})
                    if p == "/api/db/counts":
                        return self._json(twin.db.counts())
                except Exception as ex:
                    return self._json({"error": str(ex)}, 500)
                return self._json({"error": "no such endpoint"}, 404)
            if u.path.startswith("/logs") or u.path.endswith((".py", ".service", ".sh", ".db")):
                return self.send_error(404)
            super().do_GET()

        def do_POST(self):
            p = urlparse(self.path).path.rstrip("/")
            try:
                n = int(self.headers.get("Content-Length", 0))
                if n > 8192:
                    return self._json({"error": "body too large"}, 413)
                body = json.loads(self.rfile.read(n) or b"{}")
                if p == "/api/twin/counterfactual":
                    return self._json(twin.counterfactual(body.get("overrides", {}), body.get("assessment_id")))
                if p == "/api/sim/control":
                    if not gw.sim:
                        return self._json({"error": "simulator is not running (start with --sim)"}, 400)
                    return self._json(gw.sim.control(body.get("scenario"), body.get("blockage")))
            except Exception as ex:
                return self._json({"error": str(ex)}, 400)
            self._json({"error": "no such endpoint"}, 404)      # telemetry can ONLY arrive over the serial port
    return H


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--serial", default=None, help="force serial device(s), comma-separated")
    ap.add_argument("--sim", nargs="?", const="storm", default=None, choices=list(SCENARIOS), help="run the scenario simulator instead of hardware")
    ap.add_argument("--host", default="0.0.0.0")
    a = ap.parse_args()
    os.makedirs(LOG_DIR, exist_ok=True)
    buzzer = Buzzer(BUZZER_GPIO)
    if a.sim:
        dbp = os.path.join(LOG_DIR, "aquamesh_sim.db")
        for ext in ("", "-wal", "-shm"):
            try: os.remove(dbp + ext)
            except OSError: pass
        vc = VClock()
        twin = Twin(dbp, C.SIM, clock=vc, mode="SIMULATED", allow_future_nodes=True,
                    installed={"FLOOD01": True, "GAS01": True, "DRAIN01": True, "RIVER01": True, "OVERFLOW": True})
        sim = SimRunner(twin, vc)
        sim.control(a.sim)
        gw = Gateway(twin, buzzer, sim)
        sim.start()
        print(f"[SIM] scenario '{a.sim}'. Every value is SIMULATED. Drain/river/overflow nodes exist only in the simulator.")
    else:
        if serial is None:
            raise SystemExit("pyserial missing:  pip install pyserial   (or: sudo apt install python3-serial)")
        topo = json.load(open(os.path.join(ROOT, "config", "topology.json")))["nodes"]
        installed = {v["hw_id"]: bool(v["installed"]) for v in topo.values()}
        future = installed.get("DRAIN01") or installed.get("RIVER01")          # real drain/river nodes: set installed:true in topology.json
        twin = Twin(os.path.join(LOG_DIR, "aquamesh.db"), C.load(CFG), allow_future_nodes=bool(future), installed=installed)
        gw = Gateway(twin, buzzer)
        threading.Thread(target=serial_loop, args=(gw, a.serial), daemon=True).start()
    threading.Thread(target=gw.watchdog, daemon=True).start()
    srv = ThreadingHTTPServer((a.host, a.port), make_handler(gw))
    print(f"AquaMesh gateway up.  Dashboard: http://{a.host}:{a.port}   calibration={twin.cal['version']}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        buzzer.close()


if __name__ == "__main__":
    main()
